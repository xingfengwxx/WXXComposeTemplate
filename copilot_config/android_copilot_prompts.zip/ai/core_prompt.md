# Core Prompt

项目级总规则占位。
