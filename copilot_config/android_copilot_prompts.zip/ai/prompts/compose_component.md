Compose 组件 Prompt
