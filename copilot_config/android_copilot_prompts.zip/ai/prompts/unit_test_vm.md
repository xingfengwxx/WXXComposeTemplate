ViewModel Unit Test Prompt
