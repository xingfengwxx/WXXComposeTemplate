ViewModel Prompt
