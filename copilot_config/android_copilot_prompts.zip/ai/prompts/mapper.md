Mapper Prompt
