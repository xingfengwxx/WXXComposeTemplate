Compose 页面 Prompt
