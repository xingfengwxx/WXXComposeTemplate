UseCase Prompt
