Retrofit API Prompt
