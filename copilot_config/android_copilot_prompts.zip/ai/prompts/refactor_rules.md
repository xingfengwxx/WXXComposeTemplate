Refactor Rules Prompt
