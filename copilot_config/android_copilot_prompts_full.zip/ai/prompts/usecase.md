生成 UseCase：
- suspend operator fun invoke
- 单一职责
