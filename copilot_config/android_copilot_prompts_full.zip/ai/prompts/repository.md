生成 Repository：
- Flow<Result<T>>
- 不返回 null
