生成可复用 Compose 组件：
- 单一职责
- 无业务逻辑
- 支持 Preview
