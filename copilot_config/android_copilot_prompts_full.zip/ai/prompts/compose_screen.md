生成 Compose 页面：
- Material 3
- StateFlow 状态
- Loading / Error / Content
- 支持 Preview
