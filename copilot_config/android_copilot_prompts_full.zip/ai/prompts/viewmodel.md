生成 ViewModel：
- 使用 StateFlow
- viewModelScope
- 管理 UiState
