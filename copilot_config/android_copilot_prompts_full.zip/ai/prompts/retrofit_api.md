生成 Retrofit API：
- suspend 函数
- 返回 DTO
