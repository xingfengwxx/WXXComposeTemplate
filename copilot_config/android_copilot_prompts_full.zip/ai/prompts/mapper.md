生成 Mapper：
- DTO → Domain
- 扩展函数
