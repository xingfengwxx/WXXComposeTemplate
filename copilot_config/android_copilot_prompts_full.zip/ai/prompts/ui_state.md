生成 UiState：
- isLoading
- data
- error
