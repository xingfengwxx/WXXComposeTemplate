生成 ViewModel 单测：
- JUnit + MockK
- 成功 / 失败
