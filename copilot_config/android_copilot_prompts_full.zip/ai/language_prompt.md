# Language Rules

- 默认使用简体中文进行沟通
- 代码使用英文命名
